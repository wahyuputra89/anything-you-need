<?php
    for($a=10 $a=2; $a-2){
        echo "Nilai A adalah $a <br>";
    }
?>