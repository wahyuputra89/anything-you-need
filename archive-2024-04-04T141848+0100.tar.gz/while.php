<?php
    $a = 10;
    echo "Mulai hitung mundur <br>";
    while($a>=1){
        echo $a, "<br>";
        $a--;
    }
    echo "Hitung selesai";
?>