<?php
    $var = 1;
    do{
        echo $var, " ";
        $var++;
    }while($var <= 10);
?>