<?php
    $a = 1;
    echo "Hitung maju mulai <br>";
    while($a<=5){
        echo $a, "<br>";
        $a++;
    }
    echo "Hitung maju selesai <br>";
    $b = 5;
    echo "Hitung mundur mulai <br>";
    while($b>=1){
        echo $b, "<br>";
        $b--;
    }
    echo "Hitung mundur selesai <br> ";
    echo "Yuk pulang";
?>