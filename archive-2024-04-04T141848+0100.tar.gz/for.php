<?php
    for($b=10; $b >=0; $b--){
        echo "Nilai A adalah $b <br>" ;
        $b--;
    }
?>